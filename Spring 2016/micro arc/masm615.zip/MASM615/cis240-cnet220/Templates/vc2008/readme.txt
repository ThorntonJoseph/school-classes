import the exported-settings.vssettings inside of the visual studio express 2008 program.  this will configure the vc2008 to point to the build files and debug files used in masm615 and the vc6 debugger.

to incorporate the vc6 debugger into vc2008 download msdev98.zip from: 

http://academic.cuesta.edu/cakelian/Downloads.htm

and copy the msdev98.zip file to:

C:\Program Files\Microsoft Visual Studio 9.0\Common7\

then unzip it


