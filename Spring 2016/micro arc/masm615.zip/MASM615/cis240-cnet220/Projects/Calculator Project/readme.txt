The three folders contain different versions of the calculator project template.

The calculator project pdf file shows how you can build points for the project.

calculator-example.exe is an example of a basic version of the calculator which implement add32 and sub32 routines.