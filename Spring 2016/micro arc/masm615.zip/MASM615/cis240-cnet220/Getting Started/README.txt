The files PWB.bat or PWB-Full-Srceen.bat in the masm615 folder will start the 16 bit editor, assembler and debugger.  The configuration should match the labs.

The 32 bit assembler for Visual C++ will require separate configuration.  There are two html files in this directory that show how to set up version vc6.0 or vc2008

