package com.mycompany.a2;

import java.util.Random;
public interface IMoving {
	public void Moveit();

}
