package com.mycompany.a2;

public interface ICollection {
	public IIterator iterator();
	public void add(Object insert);
}
