package com.mycompany.a2;

import com.codename1.ui.Component;

public class MyComponent extends Component{
	
}
