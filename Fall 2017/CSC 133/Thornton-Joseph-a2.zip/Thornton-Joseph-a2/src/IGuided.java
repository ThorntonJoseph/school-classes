package com.mycompany.a2;


public interface IGuided {
	public void moveleft();
	 public void moveright();
	 public void moveup();
	 public void movedown();
	 public void jumptolocation(Location l);
}
