Their are no major changes to project specification

command line run chagnes:
�java -cp dist\A1Prj.jar;JavaSE.jar
com.codename1.impl.javase.Simulator com.mycompany.a1.Starter
is changed to 
�java -cp dist\A2Prj.jar;JavaSE.jar
com.codename1.impl.javase.Simulator com.mycompany.a2.Starter